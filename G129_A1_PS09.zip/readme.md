Step 1 : Download package from this url https://graphviz.org/download/#executable-packages
Step 2 : run pip uninstall graphviz command 
Above steps are required to print the tree in PDF format.
Code which will generate PDF file is commented

       # dot = Digraph(comment="AVL Tree")
       # _print_tree(self.root, dot)
       # dot.render(os.path.join('trees', fileName),view=True)
Once step 1 and 2 are completed above code can be uncommented